package com.example.myapplication2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AddWeightActivity extends AppCompatActivity {

    private EditText weightEditText;
    private Button saveButton;
    private int userId; // To store the logged-in user's ID
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Initialize UI components
        weightEditText = findViewById(R.id.weight);
        saveButton = findViewById(R.id.save_weight_button);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Retrieve the user ID from the intent
        userId = getIntent().getIntExtra("user_id", -1);

        // Check if user ID is valid
        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish(); // Close activity if user ID is invalid
            return;
        }

        // Set up save button click listener
        saveButton.setOnClickListener(v -> handleSave());
    }

    /**
     * Sends an SMS message to the specified phone number.
     *
     * @param phoneNumber The recipient's phone number.
     * @param message The message to be sent.
     */
    private void sendSms(String phoneNumber, String message) {
        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                // Send SMS
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                // Handle SMS sending failure
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            // Notify user if SMS permission is not granted
            Toast.makeText(this, "SMS permission is not granted", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles the save button click event.
     */
    private void handleSave() {
        // Retrieve weight from EditText
        String weightStr = weightEditText.getText().toString();

        // Check if weight is not empty
        if (TextUtils.isEmpty(weightStr)) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert weight to double
        double weight = Double.parseDouble(weightStr);
        // Get the current date
        String date = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());

        // Insert weight into database
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(DatabaseHelper.COLUMN_DATE, date);

        long newRowId = db.insert(DatabaseHelper.TABLE_WEIGHTS, null, values);

        // Check if insertion was successful
        if (newRowId != -1) {
            Toast.makeText(this, "Weight saved successfully", Toast.LENGTH_SHORT).show();
            // Send SMS notification
            sendSms("1234567890", "New weight entry added: " + weight + " on " + date); // Replace with actual number and message
            setResult(RESULT_OK);
            finish(); // Close activity
        } else {
            // Notify user if saving failed
            Toast.makeText(this, "Failed to save weight. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}



