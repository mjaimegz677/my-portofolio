package com.example.myapplication2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        databaseHelper = new DatabaseHelper(this);

        // Set click listeners for buttons
        loginButton.setOnClickListener(v -> handleLogin());
        createAccountButton.setOnClickListener(v -> handleCreateAccount());
    }

    /**
     * Handles the login process by checking the entered username and password.
     */
    private void handleLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate input
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = null;
        try {
            // Query the database to find matching user credentials
            cursor = db.query(DatabaseHelper.TABLE_USERS,
                    new String[]{DatabaseHelper.COLUMN_ID},
                    DatabaseHelper.COLUMN_USERNAME + "=? AND " + DatabaseHelper.COLUMN_PASSWORD + "=?",
                    new String[]{username, password}, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
                if (idIndex == -1) {
                    throw new IllegalStateException("Column ID not found in cursor");
                }
                int userId = cursor.getInt(idIndex);
                Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                intent.putExtra("user_id", userId); // Pass user_id to the next activity
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid login. Please try again or create an account.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace to logcat for debugging
            Toast.makeText(this, "An error occurred during login", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Handles the account creation process by inserting new user credentials into the database.
     */
    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate input
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
        } else {
            SQLiteDatabase db = databaseHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_USERNAME, username);
            values.put(DatabaseHelper.COLUMN_PASSWORD, password);
            long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);

            if (newRowId != -1) {
                Toast.makeText(this, "Account created successfully. Please log in.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account creation failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

