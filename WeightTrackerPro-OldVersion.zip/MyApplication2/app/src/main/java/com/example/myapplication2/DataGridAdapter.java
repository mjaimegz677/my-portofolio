package com.example.myapplication2;

import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.List;

public class DataGridAdapter extends BaseAdapter {

    private final Context context;
    private final List<WeightEntry> weightEntries;
    private final LayoutInflater inflater;

    public DataGridAdapter(Context context, List<WeightEntry> weightEntries) {
        this.context = context;
        this.weightEntries = weightEntries;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return weightEntries.size();
    }

    @Override
    public Object getItem(int position) {
        return weightEntries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflate the view for each item in the grid
        View view = inflater.inflate(R.layout.grid_item, parent, false);
        TextView dateTextView = view.findViewById(R.id.date_text);
        TextView weightTextView = view.findViewById(R.id.weight_text);
        Button deleteButton = view.findViewById(R.id.delete_button);
        Button updateButton = view.findViewById(R.id.update_button);

        // Get the weight entry for the current position
        WeightEntry entry = weightEntries.get(position);
        dateTextView.setText(entry.getDate());
        weightTextView.setText(String.valueOf(entry.getWeight()));

        // Set up the delete button to remove the weight entry from the database
        deleteButton.setOnClickListener(v -> {
            ((DataDisplayActivity) context).deleteWeightFromDatabase(entry.getId());
        });

        // Set up the update button to show a dialog for updating the weight entry
        updateButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Update Weight");

            // Create an input field for the new weight value
            final EditText input = new EditText(context);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            builder.setView(input);

            // Handle positive button click to update the weight entry
            builder.setPositiveButton("OK", (dialog, which) -> {
                String newWeightStr = input.getText().toString();
                if (!newWeightStr.isEmpty()) {
                    double newWeight = Double.parseDouble(newWeightStr);
                    ((DataDisplayActivity) context).updateWeightInDatabase(entry.getId(), newWeight);
                }
            });
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

            builder.show();
        });

        return view;
    }
}

