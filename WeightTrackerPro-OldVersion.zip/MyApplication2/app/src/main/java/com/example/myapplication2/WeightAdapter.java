package com.example.myapplication2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class WeightAdapter extends BaseAdapter {
    private final Context context;
    private final List<WeightEntry> entries;

    public WeightAdapter(Context context, List<WeightEntry> entries) {
        this.context = context;
        this.entries = entries;
    }

    @Override
    public int getCount() {
        return entries.size();
    }

    @Override
    public Object getItem(int position) {
        return entries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflate the view for each item in the grid if not recycled
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_item_weight, parent, false);
        }

        TextView dateTextView = convertView.findViewById(R.id.date_text);
        TextView weightTextView = convertView.findViewById(R.id.weight_text);

        // Get the weight entry for the current position
        WeightEntry entry = entries.get(position);
        dateTextView.setText(entry.getDate());

        // Convert the double to a String before setting the text
        weightTextView.setText(String.valueOf(entry.getWeight()));

        return convertView;
    }
}


