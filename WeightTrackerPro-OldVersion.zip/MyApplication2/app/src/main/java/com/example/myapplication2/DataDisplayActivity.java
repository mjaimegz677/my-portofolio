package com.example.myapplication2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity to display and manage weight entries.
 */
public class DataDisplayActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD_WEIGHT = 1;
    private static final int REQUEST_CODE_SMS_PERMISSION = 1;
    private DataGridAdapter adapter;
    private List<WeightEntry> weightEntries;
    private DatabaseHelper databaseHelper;
    private int userId; // To store the logged-in user's ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Retrieve the user ID from the intent
        userId = getIntent().getIntExtra("user_id", -1);

        // Check if user ID is valid
        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish(); // Close activity if user ID is invalid
            return;
        }

        // Initialize database helper and weight entries list
        databaseHelper = new DatabaseHelper(this);
        weightEntries = new ArrayList<>();

        // Initialize GridView and adapter
        GridView gridView = findViewById(R.id.data_grid);
        adapter = new DataGridAdapter(this, weightEntries);
        gridView.setAdapter(adapter);

        // Load weights from database
        loadWeightsFromDatabase(); // Ensure adapter is initialized before this

        // Set up add weight button click listener
        Button addWeightButton = findViewById(R.id.add_weight_button);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, AddWeightActivity.class);
            intent.putExtra("user_id", userId); // Pass user_id to AddWeightActivity
            startActivityForResult(intent, REQUEST_CODE_ADD_WEIGHT);
        });

        // Set up logout button click listener
        Button logoutButton = findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close activity
        });

        // Set up request permission button click listener
        Button requestPermissionButton = findViewById(R.id.request_permission_button);
        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * Loads weight entries from the database and updates the adapter.
     */
    private void loadWeightsFromDatabase() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_WEIGHTS, null,
                DatabaseHelper.COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, DatabaseHelper.COLUMN_DATE + " ASC");

        weightEntries.clear();
        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT_ID);
            int dateIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE);
            int weightIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);

            // Check if all columns are present
            if (idIndex == -1 || dateIndex == -1 || weightIndex == -1) {
                Toast.makeText(this, "Database columns are missing", Toast.LENGTH_SHORT).show();
                cursor.close();
                return;
            }

            do {
                int id = cursor.getInt(idIndex);
                String date = cursor.getString(dateIndex);
                double weight = cursor.getDouble(weightIndex); // Use double instead of float
                weightEntries.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());

            cursor.close();
            adapter.notifyDataSetChanged(); // Notify adapter of data changes
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Check if the result is from AddWeightActivity and was successful
        if (requestCode == REQUEST_CODE_ADD_WEIGHT && resultCode == RESULT_OK) {
            loadWeightsFromDatabase(); // Reload data after adding a new weight
        }
    }

    /**
     * Deletes a weight entry from the database.
     *
     * @param weightId The ID of the weight entry to be deleted.
     */
    public void deleteWeightFromDatabase(int weightId) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsDeleted = db.delete(DatabaseHelper.TABLE_WEIGHTS,
                DatabaseHelper.COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(weightId)});

        // Notify user of deletion result
        if (rowsDeleted > 0) {
            Toast.makeText(this, "Weight entry deleted", Toast.LENGTH_SHORT).show();
            loadWeightsFromDatabase(); // Reload data after deletion
        } else {
            Toast.makeText(this, "Failed to delete weight entry", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Updates a weight entry in the database.
     *
     * @param weightId The ID of the weight entry to be updated.
     * @param newWeight The new weight value.
     */
    public void updateWeightInDatabase(int weightId, double newWeight) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_WEIGHT, newWeight);

        int rowsUpdated = db.update(DatabaseHelper.TABLE_WEIGHTS,
                values,
                DatabaseHelper.COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(weightId)});

        // Notify user of update result
        if (rowsUpdated > 0) {
            Toast.makeText(this, "Weight entry updated", Toast.LENGTH_SHORT).show();
            loadWeightsFromDatabase(); // Reload data after update
        } else {
            Toast.makeText(this, "Failed to update weight entry", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Requests SMS permission if not already granted.
     */
    private void requestSmsPermission() {
        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS}, REQUEST_CODE_SMS_PERMISSION);
        } else {
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Handle the result of SMS permission request
        if (requestCode == REQUEST_CODE_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}




